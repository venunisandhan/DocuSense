aws_region    = "ap-south-1"
instance_type = "t3.micro"

my_ip_cidr = "0.0.0.0/0"


ssh_public_key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJDVu9Xo/QFhogUwfvzbuS9s57Rvao4E5lrflfC7Tbw4 docusense"


repo_url = "https://github.com/venunisandhan/DocuSense.git"


s3_bucket_name = "docusense-documents"


jwt_access_secret         = "ff26ea8e69a8656a49ef3445b4e69ac78add0c845f1af4de5dcf392701f1d561"
jwt_refresh_secret        = "4657c0ce03d696c45898cac2c4a7f1b36d0d20e61620b558cc33ec2aafd8021e"
pending_role_token_secret = "ce03d696c45nsgfbnaeb898cac2c4a7f1b36h0e61620b558cc33ec2aafd8021e"

google_client_id     = "255759069057-b0vn26cvokuif0bc313rum40013qicad.apps.googleusercontent.com"
google_client_secret = "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"


gemini_api_key = "AQ.Ab8RN6I3WD-mimf83l0CbxpWWjYtp6tgo3_-YO1joKQ-h-Ys0Q"

mongo_uri = "mongodb+srv://venu:1234@cluster0.mtd1qbd.mongodb.net/docusense?retryWrites=true&w=majority"
